DINOTEM EDITOR 18

Supported Platforms
DEMO/FULL PC/XBOX/PS3

General Features
Edit the file .bin:
- Player.bin
- PlayerAssignement.bin
- PlayerAppareance.bin
- Team.bin
- Country.bin
- Tactics.bin
- TacticsFormation.bin
- Ball.bin
- BallCondition.bin
- Stadium.bin
- CompetitionRegulation.bin
- CompetitionEntry.bin
- Coach.bin
- Competition.bin
- CompetitionKind.bin
- Derby.bin
- StadiumOrder.bin
- StadiumOrderInConfederation.bin
- Boots.bin
- Glove.bin

Player's editor
- Name
- Shirt name
- Japanese name
- Nationality
- 2nd Nationality
- Player styles
- Age
- Height and weight
- Stronger foot
- Form, we acc/usage and injury res
- Hidden player
- Positions
- Stats
- Skills
- COM playing styles
- Player's motions
- Stats adjustments
- Remove Fake ID
- Copy/Paste player stats from PesStatsDatabase (PSD)
- Change skin colour
- Has won golden ball
- Star player indicator
- Youth club
- Import player's stats from FM 2017 (152188 players)
- Search FM 2017 players by names
- Search FM 2017 players by clubs
- Filter FM 2017 player's search by club
- Filter FM 2017 player's search by nationality
- Boots relink
- Gloves relink

Team's editor
- Names ( 15 languages supported )
- Short name
- Country
- Fake team
- Non playable league
- License
- Coach license
- Team's stadium
- Has Licensed Players
- Anthem Standing Style
- Anthem Players Singing
- Anthem Standing Angle
- Has Anthem
- Derby's relink

Team's transfers editor
- Transfer players (with Drag&Drop Function)
- Search players by name
- Change player's number in team
- Change player's name in team
- Change player's shirt name in team

Drag&Drop function
- Transfer player between teams
- Transfer player from all player's list
- Remove player in formation
- Move player in formation

Team's formation editor
- Change formations (Custom, Offensive and Defensive)
- Changing formations quickly by selecting the module
- Change player's position
- Change player's position in the pitch with a click
- Change kickers
- Change tactics (Build up, defensive style...)

Ball's editor
- Name
- Order

Coach's editor
- Name
- Nationality
- License id

Stadium's editor
- Name
- Japanese Name
- Konami Name
- Capacity
- Country
- Zone
- License
- Paste from database

Glove's editor
- Name
- Color
- Order

Boot's editor
- Name
- Color
- Material
- Order

Competition's editor
- Competition Study
- Relink league


Export/Import function
- Players + teams [CSV]
- Teams [CSV]
- Players [CSV]
- Balls [CSV]
- PlayerAppareance [CSV]
- Ball Condition [CSV]
- Export player
- Import player (PES 2018 only / Dino Editor)
- Export playerAppareance
- Import playerAppareance (PES 2018 only / Dino Editor)

Database
- Stadium: [PES 14/PES 15/PES 16]
Stadium Name, Hex, Home Stadium, Real Name, DLC
 
Global Functions
- Change all player's names in upper/lower/first up format
- Change all teams's names in upper/lower/first up format

Extra Features
- Compatible with all DLC's
- All bootspack are supported
- All ballspack are supported
- All stadiumspack are supported
- Remove fake teams names
- Remove classic players fake names
- Add new gloves, balls, boots, coaches, stadiums, derby, players, teams
- Generate auto CPK